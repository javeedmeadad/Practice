package com.practice.linkedlist;

public class Mymain {

	public static void main(String[] args) {
		
		MyLinkedList my=new MyLinkedList();
		
		
		
		my.insert(10);
		my.insert(1);
		my.insert(15);
		my.insert(110);
		my.insertAtStart(1);
		my.insertAt(2, 23);
		my.delete(0);
		my.display();
	}
}
